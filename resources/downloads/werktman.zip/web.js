//web.js
var http = require('http');

module.exports = {
  "publish": function (buffer) {
    http.createServer(function (req, res) {
      res.end(buffer);
    }).listen(1024);
  }
} 
