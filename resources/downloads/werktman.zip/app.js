//Handen uit de mouwen!

//Importeren van het database dataobject
var database = require('./database.json');
var web = require('./web');

var publishbuffer = '';

for (entry of database.data) {
  if (entry.type == 'docent') {
    publishbuffer += entry.name + '\n';
  }
}

web.publish(publishbuffer);
